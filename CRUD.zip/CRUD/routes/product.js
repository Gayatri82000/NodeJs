const express = require('express');
const connection = require('../connection');
const router = express.Router();

/*
Sequence Summary:
    Run server.js → Starts the HTTP server.
    Load index.js → Sets up the Express app and middleware.
    Load product.js → Defines routes for product CRUD operations.
    Load connection.js → Connects to the MySQL database.
Request Handling:
    Server receives a request (e.g., /product/create).
    Routes the request to product.js.
    Executes the corresponding SQL query using connection.js.
    Sends a response back to the client.
This process repeats for every request made to the server! Let me know if you need more details on any step.
*/

router.post('/create',(req,res,next)=>{
    let product = req.body;
    query = "Insert into product(name, description,price)values(?,?,?)";
    connection.query(query,[product.name,product.description,product.price],(err,results)=>{
        if(!err){
            return res.status(200).json({message : "Product added successfully"});
        }
        else
        return res.status(500).json(err);
    })
})


router.get('/read',(req,res,next)=>{
    let product = req.body;
    query = "Select * from product;";
    connection.query(query,(err,results)=>{
        if(!err){
            return res.status(200).json(results);
        }
        else
        return res.status(500).json(err);
    })
})

router.patch('/update/:id',(req,res,next)=>{
    const id = req.params.id;
    let product = req.body;
    query = "Update product set name=?, description= ?, price=? where id=?;";
    connection.query(query,[product.name,product.description,product.price,id],(err,results)=>{
        if(!err){
            if(results.affectedRows==0){
                return res.status(404).json("Product id does not found");
            }
            return res.status(200).json({message : "Product updated successfully"});
        }
        else
            return res.status(500).json(err);
    })
})

router.delete('/delete/:id',(req,res,next)=>{
    const id = req.params.id;
    // let product = req.body;
    query = "Delete from product where id=?;";
    connection.query(query,[id],(err,results)=>{
        if(!err){
            if(results.affectedRows==0){
                return res.status(404).json("Product id does not found");
            }
            return res.status(200).json({message : "Product deleted successfully"});
        }
        else
            return res.status(500).json(err);
    })
})

module.exports = router;