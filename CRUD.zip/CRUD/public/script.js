// Function to load all products
function loadProducts() {
    fetch('/product/read')
        .then(response => response.json())
        .then(products => {
            const productTableBody = document.getElementById('product-table-body');
            productTableBody.innerHTML = ''; // Clear table body

            products.forEach(product => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${product.name}</td>
                    <td>${product.description}</td>
                    <td>${product.price}</td>
                    <td>
                        <button onclick="editProduct(${product.id})">Edit</button>
                        <button onclick="deleteProduct(${product.id})">Delete</button>
                    </td>
                `;
                productTableBody.appendChild(row);
            });
        })
        .catch(error => console.error('Error loading products:', error));
}

// Function to create or update a product
function createOrUpdateProduct() {
    const name = document.getElementById('product-name').value;
    const description = document.getElementById('product-description').value;
    const price = document.getElementById('product-price').value;
    const id = document.getElementById('product-id').value;

    const productData = { name, description, price };

    // Determine if it's an update or create operation
    const url = id ? `/product/update/${id}` : '/product/create';
    const method = id ? 'PATCH' : 'POST';

    fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productData)
    })
    .then(response => response.json())
    .then(result => {
        alert(result.message);
        clearForm();
        loadProducts();
    })
    .catch(error => console.error('Error creating/updating product:', error));
}

// Function to edit a product (populate the form with product data)
function editProduct(id) {
    fetch('/product/read')
        .then(response => response.json())
        .then(products => {
            const product = products.find(p => p.id === id);
            if (product) {
                document.getElementById('product-name').value = product.name;
                document.getElementById('product-description').value = product.description;
                document.getElementById('product-price').value = product.price;
                document.getElementById('product-id').value = product.id; // Hidden input to store id
            }
        })
        .catch(error => console.error('Error editing product:', error));
}

// Function to delete a product
function deleteProduct(id) {
    if (confirm('Are you sure you want to delete this product?')) {
        fetch(`/product/delete/${id}`, { method: 'DELETE' })
            .then(response => response.json())
            .then(result => {
                alert(result.message);
                loadProducts();
            })
            .catch(error => console.error('Error deleting product:', error));
    }
}

// Function to clear the form after submission
function clearForm() {
    document.getElementById('product-name').value = '';
    document.getElementById('product-description').value = '';
    document.getElementById('product-price').value = '';
    document.getElementById('product-id').value = ''; // Clear hidden id input
}

// Load products when the page loads
document.addEventListener('DOMContentLoaded', loadProducts);
