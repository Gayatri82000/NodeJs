// const express = require("express");
// // const connection = require("./connection");
// const productRoute = require("./routes/product")
// const app = express();

// app.use(express.urlencoded({extended : true}));
// app.use(express.json());
// app.use('/product',productRoute);


// module.exports = app;



const express = require("express");
const path = require("path");  // Add path module

const connection = require("./connection");
const productRoute = require("./routes/product");
const app = express();

// Middleware to handle JSON and URL-encoded form data
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files from 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Use routes for product
app.use('/product', productRoute);

module.exports = app;
