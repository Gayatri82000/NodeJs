Create table product(
    id int NOT NULL AUTO_INCREMENT,
    name varchar(255) NOT NULL,
    description varchar(255),
    price integer,
    PRIMARY KEY(id)
);