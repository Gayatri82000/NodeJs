var fs = require('fs');

fs.appendFile('demofile1.html', 'Hello content!', function (err) {
  if (err) throw err;
  console.log('Saved!');
});